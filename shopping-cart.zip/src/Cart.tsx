import React from 'react';
import ProductsList from "./Products/ProductsList";
import ProductForm from "./Products/ProductForm";
import {useAppSelector} from "./store.hooks";
import {getTotalPrice, getTotalAmount} from "./Products/products.slice";

const Cart: React.FC = () => {

    const totalPrice = useAppSelector(getTotalPrice)
    const totalAmount = useAppSelector(getTotalAmount)

    return (
        <div>
            <h5>{totalPrice}</h5>
            <h5>{totalAmount}</h5>
            <ProductsList/>
            <ProductForm/>
        </div>
    );
};

export default Cart;
